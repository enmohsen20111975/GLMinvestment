/**
 * GET /api/v2/unified/config
 * ===========================
 * Unified analysis configuration endpoint.
 *
 * Returns the combined configuration that the Flutter app needs to render
 * the Unified Analysis dashboard:
 *   - personas (investor, gambler, swing, scalper, balanced, ...)
 *   - markets  (EGX, TADAWUL, KSE, QSE, US, CRYPTO, ...)
 *   - engines  (technical, fundamental, macro, sentiment, confluence, ...)
 *   - weights  (per-persona engine weighting)
 *   - presets, pipelines (best-effort — pulled from existing v2 endpoints)
 *
 * Behaviour:
 *   1. Try Python `${PY}/api/v2/unified/config` (passes ?market & ?persona through).
 *   2. If Python 404s or fails, fall back to a local static config that is
 *      merged with anything we can fetch from /api/v2/engines, /api/v2/presets,
 *      and /api/v2/pipelines.
 *
 * Always returns HTTP 200 with `{success: true, config: {...}}` so the
 * Flutter app's UI renders even when the Python backend is partially down.
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSelfBaseUrl } from '@/lib/server-url';
import { SIGNAL_THRESHOLDS } from '@/lib/canonical-signal';
import { MARKET_PROFILE_DEFAULTS, listMarketProfiles } from '@/lib/market-profile';

export const dynamic = 'force-dynamic';

const PY = process.env.EGXPY_SERVICE_URL || 'http://127.0.0.1:8010';

// ---------------------------------------------------------------------------
// Static defaults
// ---------------------------------------------------------------------------

const PERSONAS = [
  {
    id: 'investor',
    name: 'المستثمر',
    name_en: 'Investor',
    description: 'استثمار طويل الأجل مبني على الأساسيات والقيمة العادلة',
    description_en: 'Long-term value investing based on fundamentals',
    risk_level: 'low',
    timeframe: 'weeks-months',
    color: '#10b981',
    min_score: 70,
    default_top_n: 15,
    weights: { technical: 0.20, fundamental: 0.45, macro: 0.15, sentiment: 0.10, confluence: 0.10 },
  },
  {
    id: 'gambler',
    name: 'المغامر',
    name_en: 'Gambler',
    description: 'مضاربة عالية المخاطر بحثًا عن فرص انفجارية',
    description_en: 'High-risk speculation hunting explosive moves',
    risk_level: 'high',
    timeframe: 'intraday',
    color: '#ef4444',
    min_score: 65,
    default_top_n: 20,
    weights: { technical: 0.55, fundamental: 0.05, macro: 0.05, sentiment: 0.15, confluence: 0.20 },
  },
  {
    id: 'swing',
    name: 'المتأرجح',
    name_en: 'Swing',
    description: 'تداول متوسط الأجل على موجات السهم',
    description_en: 'Medium-term swing trading on price waves',
    risk_level: 'medium',
    timeframe: 'days-weeks',
    color: '#3b82f6',
    min_score: 60,
    default_top_n: 20,
    weights: { technical: 0.50, fundamental: 0.20, macro: 0.10, sentiment: 0.10, confluence: 0.10 },
  },
  {
    id: 'scalper',
    name: 'المضارب السريع',
    name_en: 'Scalper',
    description: 'تداول فائق السرعة داخل اليوم',
    description_en: 'Ultra-fast intraday scalping',
    risk_level: 'very_high',
    timeframe: 'minutes-hours',
    color: '#f59e0b',
    min_score: 75,
    default_top_n: 10,
    weights: { technical: 0.70, fundamental: 0.00, macro: 0.05, sentiment: 0.15, confluence: 0.10 },
  },
  {
    id: 'balanced',
    name: 'المتوازن',
    name_en: 'Balanced',
    description: 'مزيج متوازن من كل المحركات',
    description_en: 'Balanced blend of all engines',
    risk_level: 'medium',
    timeframe: 'days-weeks',
    color: '#8b5cf6',
    min_score: 65,
    default_top_n: 20,
    weights: { technical: 0.25, fundamental: 0.25, macro: 0.20, sentiment: 0.15, confluence: 0.15 },
  },
];

const MARKETS = [
  { id: 'EGX',     name: 'البورصة المصرية',         name_en: 'Egyptian Exchange',     currency: 'EGP', country: 'Egypt',     default: true },
  { id: 'TADAWUL', name: 'السوق السعودي',           name_en: 'Saudi Exchange',        currency: 'SAR', country: 'Saudi Arabia' },
  { id: 'KSE',     name: 'بورصة الكويت',            name_en: 'Kuwait Stock Exchange', currency: 'KWD', country: 'Kuwait' },
  { id: 'QSE',     name: 'بورصة قطر',               name_en: 'Qatar Stock Exchange',  currency: 'QAR', country: 'Qatar' },
  { id: 'US',      name: 'الأسواق الأمريكية',        name_en: 'US Markets',            currency: 'USD', country: 'United States' },
  { id: 'CRYPTO',  name: 'العملات الرقمية',         name_en: 'Crypto Markets',        currency: 'USD', country: 'Global' },
];

const ENGINES = [
  {
    id: 'technical',
    name: 'المحرك الفني',
    name_en: 'Technical Engine',
    description: 'مؤشرات فنية، اتجاهات، دعم ومقاومة',
    description_en: 'Technical indicators, trends, support/resistance',
    enabled: true,
    category: 'price_action',
    default_weight: 0.30,
  },
  {
    id: 'fundamental',
    name: 'المحرك الأساسي',
    name_en: 'Fundamental Engine',
    description: 'Piotroski, Altman Z, FCF، نمو الإيرادات',
    description_en: 'Piotroski, Altman Z, FCF, revenue growth',
    enabled: true,
    category: 'valuation',
    default_weight: 0.30,
  },
  {
    id: 'macro',
    name: 'المحرك الكلي',
    name_en: 'Macro Engine',
    description: 'سياق الاقتصاد الكلي وأداء القطاعات',
    description_en: 'Macroeconomic context and sector performance',
    enabled: true,
    category: 'context',
    default_weight: 0.15,
  },
  {
    id: 'sentiment',
    name: 'محرك المشاعر',
    name_en: 'Sentiment Engine',
    description: 'تحليل الأخبار والمشاعر السوقية',
    description_en: 'News analysis and market sentiment',
    enabled: true,
    category: 'news',
    default_weight: 0.10,
  },
  {
    id: 'confluence',
    name: 'مجلس المستشارين',
    name_en: 'Confluence Engine',
    description: '5 مستشارين (فني/أساسي/كلي/اتجاه/شخصية) مع توافق الآراء',
    description_en: '5 counselors (tech/fund/macro/trend/personality) with consensus',
    enabled: true,
    category: 'aggregate',
    default_weight: 0.15,
  },
];

const PIPELINES = [
  { id: 'default',        name: 'الخط الافتراضي',  name_en: 'Default Pipeline',        stages: ['technical', 'fundamental', 'macro', 'sentiment', 'confluence'] },
  { id: 'fast',           name: 'خط سريع',          name_en: 'Fast Pipeline',            stages: ['technical', 'confluence'] },
  { id: 'fundamentals',   name: 'خط الأساسيات',     name_en: 'Fundamentals Pipeline',    stages: ['fundamental', 'macro'] },
  { id: 'day-trade',      name: 'خط المضاربة',       name_en: 'Day-Trading Pipeline',     stages: ['technical', 'sentiment', 'confluence'] },
];

const PRESETS = [
  { id: 'conservative', name: 'محافظ',  name_en: 'Conservative', persona: 'investor', min_score: 80, top_n: 10 },
  { id: 'balanced',     name: 'متوازن', name_en: 'Balanced',     persona: 'balanced', min_score: 70, top_n: 15 },
  { id: 'aggressive',   name: 'هجومي',  name_en: 'Aggressive',   persona: 'gambler',  min_score: 60, top_n: 25 },
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function tryPython(pathAndQuery: string, timeoutMs = 6000): Promise<any | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(`${PY}${pathAndQuery}`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
      cache: 'no-store',
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    const data = await res.json();
    return data && (data.success === true || data.config || data.personas || data.engines)
      ? data
      : null;
  } catch { // silent fallback (safe-by-design)
    return null;
  }
}

async function tryNext(request: NextRequest, path: string, timeoutMs = 5000): Promise<any | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const selfBase = getSelfBaseUrl(request);
    const res = await fetch(`${selfBase}${path}`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
      cache: 'no-store',
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    return await res.json();
  } catch { // silent fallback (safe-by-design)
    return null;
  }
}

// ---------------------------------------------------------------------------
// GET handler
// ---------------------------------------------------------------------------

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const market  = searchParams.get('market')  || 'EGX';
    const persona = searchParams.get('persona') || 'balanced';

    // 1) Try Python unified/config first
    const qs = `?market=${encodeURIComponent(market)}&persona=${encodeURIComponent(persona)}`;
    const pyData = await tryPython(`/api/v2/unified/config${qs}`);
    if (pyData && pyData.config) {
      return NextResponse.json({ success: true, config: pyData.config, source: 'python' });
    }

    // 2) Best-effort: enrich static config with live endpoints that may work
    const [enginesResp, presetsResp, pipelinesResp] = await Promise.all([
      tryNext(request, '/api/v2/engines'),
      tryNext(request, '/api/v2/presets'),
      tryNext(request, '/api/v2/pipelines'),
    ]);

    const engines = enginesResp?.engines && Array.isArray(enginesResp.engines) && enginesResp.engines.length
      ? enginesResp.engines
      : ENGINES;

    const presets = presetsResp?.presets && Array.isArray(presetsResp.presets) && presetsResp.presets.length
      ? presetsResp.presets
      : PRESETS;

    const pipelines = pipelinesResp?.pipelines && Array.isArray(pipelinesResp.pipelines) && pipelinesResp.pipelines.length
      ? pipelinesResp.pipelines
      : PIPELINES;

    // Resolve the active persona block (fall back to 'balanced' if unknown)
    const personaBlock = PERSONAS.find(p => p.id === persona) || PERSONAS.find(p => p.id === 'balanced')!;
    const marketBlock  = MARKETS.find(m => m.id === market)   || MARKETS[0];

    const config = {
      version: '2.0.0',
      generated_at: new Date().toISOString(),
      market,
      persona,
      active_persona: personaBlock,
      active_market: marketBlock,
      personas: PERSONAS,
      markets: MARKETS,
      engines,
      pipelines,
      presets,
      weights: personaBlock.weights,
      defaults: {
        top_n: personaBlock.default_top_n,
        min_score: personaBlock.min_score,
        risk_level: personaBlock.risk_level,
        timeframe: personaBlock.timeframe,
      },
      scoring: {
        min: 0,
        max: 100,
        // ARCH-OPTION-2 (2026-10-10): توحيد SIGNAL_THRESHOLDS من canonical-signal.ts
        // (كانت 80/70/60/50/40 — نظام رابع مختلف عن canonical 78/65/55/40/25)
        thresholds: {
          strong_buy: SIGNAL_THRESHOLDS.STRONG_BUY,   // 78
          buy: SIGNAL_THRESHOLDS.BUY,                  // 65
          hold: SIGNAL_THRESHOLDS.ACCUMULATE,          // 55
          avoid: SIGNAL_THRESHOLDS.REDUCE,             // 40
          strong_avoid: SIGNAL_THRESHOLDS.STRONG_SELL, // 25
        },
      },
      // ARCH-OPTION-2 (2026-10-10): expose MarketProfile defaults for each market
      market_profiles: listMarketProfiles().map(key => {
        const p = MARKET_PROFILE_DEFAULTS[key];
        return {
          market_code: p.market_code,
          market_name_ar: p.market_name_ar,
          currency: p.currency,
          rsi_overbought: p.rsi_overbought,
          rsi_oversold: p.rsi_oversold,
          min_score_buy: p.min_score_buy,
          min_score_strong: p.min_score_strong,
          min_rr: p.min_rr,
          stop_max_pct: p.stop_max_pct,
          stop_min_pct: p.stop_min_pct,
          target_min_pct: p.target_min_pct,
          target_max_pct: p.target_max_pct,
          position_size_pct: p.position_size_pct,
          is_continuous_24_7: p.is_continuous_24_7,
          has_fundamentals: p.weights.fundamental > 0,
        };
      }),
    };

    return NextResponse.json({
      success: true,
      config,
      source: 'next-static',
      message_en: 'Unified config served from Next.js (Python /api/v2/unified/config not available).',
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: 'فشل تحميل إعدادات التحليل الموحد',
        error_en: 'Failed to load unified analysis config',
        details: error instanceof Error ? error.message : String(error),
        config: null,
      },
      { status: 500 }
    );
  }
}
