/**
 * GET/POST /api/stocks/presets
 * =============================
 * Thin proxy to Python backend's `/api/stocks/presets`.
 *
 * PKG2-ROUND2 (Engineering): migrated to the Unified Response Schema.
 *  - Success path: passes through Python's response shape (Rule 20 —
 *    Python is the canonical source for stock presets).
 *  - Error path: was `NextResponse.json({success:false, error:'internal_error'}, {status:503})`
 *    → now `apiErr('backend_unreachable', msg, 503)`.
 *  - Removed `catch (e)` (implicit any) → `catch (err: unknown)` with
 *    `err instanceof Error ? err.message : String(err)`.
 *  - Typed the upstream response as `unknown` (no `any`).
 *
 * Rule 27 (NO-FAKE-DATA): no fabricated presets when Python is down —
 *   client sees an explicit error.
 * Rule 67 (SSOT): error envelope carries the canonical server timestamp.
 */

import { NextRequest, NextResponse } from 'next/server';
import { apiErr } from '@/lib/api-response';

const PY = process.env.EGXPY_SERVICE_URL || 'http://127.0.0.1:8010';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const qs = url.searchParams.toString();
    const targetUrl = `${PY}/api/stocks/presets${qs ? `?${qs}` : ''}`;

    const options: RequestInit = {
      signal: AbortSignal.timeout(30000),
      cache: 'no-store',
    };
    if (req.method !== 'GET') {
      options.method = req.method;
      options.headers = { 'Content-Type': 'application/json' };
      options.body = await req.text();
    }

    const res = await fetch(targetUrl, options);
    const data: unknown = await res.json();
    // Pass through Python's response shape — Python is canonical (Rule 20).
    return NextResponse.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error('[stocks:presets]', msg);
    return apiErr('backend_unreachable', `Python backend unreachable: ${msg}`, 503);
  }
}
